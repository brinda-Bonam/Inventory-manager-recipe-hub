//Same as in assignment 4, these are the same websites used, nothing different, i got teh ucanaccess files from the same website as assignment 4 but cited them anyways 

//https://www.geeksforgeeks.org/java/introduction-to-jdbc/
//https://www.w3schools.com/sql/
//these are the websites i used in assignment 4 to learn how to connect the database file

//https://sourceforge.net/projects/ucanaccess/
//this is where i downloaded the ucanaccess files and uploaded them into the libraray/ lib folder, since i will be submitting this entire folder, hopefully you will have acesss to it too

//below are the imports that i used for the jdbc
//import java.io.File;
import java.sql.Connection;//the connection to the specific database, used to make statemenst 
import java.sql.DriverManager;//the connection  to the databse using the url 
import java.sql.ResultSet;//a table of data from teh database based on specific instructions 
import java.sql.SQLException;//handles exceptions 
import java.sql.Statement;// used for the actual selcts and updates


//i also used a try catch and made a connection to the databse everytime so i will not be commenting it as much after the first time 

public class Database {
    private String file = "src\\Inventory.accdb";
    private String url = "jdbc:ucanaccess://" + file;//the actual url taht is used by the driver manager to connect to the accdb file

    public void setter(String path){
        file = path;
        url = "jdbc:ucanaccess://" + file;
        System.out.println("file path updated to: " + file);
    }
    public String getter(){
        return file;
    }
    public ResultSet find(String sql){
        try {
            Connection conn = DriverManager.getConnection(url);
            Statement st = conn.createStatement();
            return st.executeQuery(sql);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    public String find(String sql, String column){//this method simple finds the sql injection and returns that specific string, it should be a single string since its asking for only used for individual first and last names, mainly
        try{//same as above methods, connects to teh database lines 65-67 are repeated throughout the code
            Connection conn = DriverManager.getConnection(url);
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            if (rs.next()){
                String info = rs.getString(column);//gets the string info for the column asked, like you could call teh method asking for first name once and lastt name teh next time, used to collect string information from the database 
                return info;                          
            }
            return "Not Found";//if there is no value for the sql injection it returns not found
        }
         catch(SQLException e){
            e.printStackTrace();
            return "SQL issue!";//returns sql issue if something wnet wrong to error catch 
        }
    }
    public void update(String itemName, int newQuantity){
        String sql = "UPDATE Inventorytbl SET Quantity = " + newQuantity + " WHERE ItemName = '" + itemName + "'";
    try (Connection conn = DriverManager.getConnection(url);
        Statement st = conn.createStatement()) {
        st.executeUpdate(sql);
        System.out.println("Database updated!");
    } catch (SQLException e) {
        e.printStackTrace();
    }
    }
}
