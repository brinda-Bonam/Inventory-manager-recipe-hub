import java.awt.Color; //used to change the background color 
import java.awt.Dimension;//used to set the bounds and dimesions 
import java.awt.Desktop;
import java.net.URI;
import java.awt.Font; //used to change the font 
import java.awt.Image;//used with the images since i brought in images for teh student id 
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.GridLayout;//used a gridlayout for the editing aspect of the admins tab
//import java.util.Random;//random generator to get a randomized scedhule 

import javax.swing.*;//calls everything related to the graphics 

//https://docs.oracle.com/javase/tutorial/uiswing/components/icon.html
//https://youtu.be/Kmgo00avvEw?si=YysvMUzI6jSmi_lQ
//https://youtu.be/f5uw1zHNcNY?si=vCPW3daLp3u5voEc

//READ- i will be commenting but the code is VERYYY repetitive, setting the text, setting the bounds and setting font and style initalizing the labels n stuff are very repetivive that i may not repeat for all lines
//some of these comments on graphics are the same from my assignments because i was citing the same sources that taught me then, and its the same concepts, JFrame is again not complicated but very repetitive and tedius 

public class Jframe extends JFrame{//creates a new class that has the same properties as a jframe and makes a new window

    //I will be explaining the main parts of teh graphics here so as to not repeat myself multiple times

    //Jlabels = text, can set the text, location and font. 
    //use "setVisibility" to make something appear and dissapear as u set it to true or false
    //majority of the labels are in this formal .setFont(new Font("Segoe Script", Font.PLAIN, 21 or 18));

    //Jframes- there is only one main frame and then panels are added to it
    //Jpanels- areas of space that have dimension and can hold stuff, used for organizing, like evryt label related to the photo id is added to the DigiID panel, teh image, name and stuff,
    //  you can make all that dissapear by simply setting the panel to visibility false 

    //Jbuttons- quote literally buttons 
    //JTextfields- inputs for the editing inforation and username/password 

    //Jmenubar creates a bar with different horizontal menus, which further have vertical memu items that u can use as buttonsish 
    JFrame frame;
    JMenuBar menu;
    JMenu Quantity;
    JMenuItem all;
    JMenuItem Dairy;
    JMenuItem Fruits;
    JMenuItem Vegitables;
    JMenuItem Staples;
    JMenuItem Other;
    JMenu Search;
    JMenu List;
    JMenu Expiration;
    JLabel intro;

    JPanel quantity;
    JPanel list;
    JPanel searchResults;
    JTextField search;
    JPanel expiry;
    JScrollPane scrollPane;
    Database db = new Database();

    //JLabel amount;

    public void MyFrame(){
        frame = new JFrame();//Creates a frame
        frame.setTitle("Pantry Organizer");//Creates a title for the frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//The frame will close when u press X
        frame.setLayout(null);//this layout helps keep the panels in order when you expand the window/frame
        frame.setSize(1000,700);//size  of the frame
        frame.getContentPane().setBackground(Color.PINK);//background colour of the frame 
        
        intro= new JLabel("Choose one of the tabs above");
        intro.setBounds(100,180, 600,200);
        intro.setFont(new Font("Segoe Script", Font.BOLD, 21));
            

        menu = new JMenuBar();
        Quantity = new JMenu("Quantity");
        Quantity.setFont(new Font("Segoe Script",Font.BOLD, 18));//sets font style for teh menu 
        
        Search = new JMenu("Search");
        Search.setFont(new Font("Segoe Script",Font.BOLD, 18));//sets font style for teh menu 
        
        List = new JMenu("List");
        List.setFont(new Font("Segoe Script",Font.BOLD, 18));//sets font style for teh menu 
        
        Expiration = new JMenu("Expiration");
        Expiration.setFont(new Font("Segoe Script",Font.BOLD, 18));//sets font style for teh menu 
             
        all = new JMenuItem("All Items");// the admin get an example photoid of teh first in line, while students get their own 
        all.setFont(new Font("Segoe Script",Font.BOLD, 18));
        Quantity.add(all);
        all.addActionListener(e -> ShowItems("All Items"));
        
        Dairy = new JMenuItem("Dairy");// the admin get an example photoid of teh first in line, while students get their own 
        Dairy.setFont(new Font("Segoe Script",Font.BOLD, 18));
        Quantity.add(Dairy);
        Dairy.addActionListener(e -> ShowItems("Dairy"));
        
        Fruits = new JMenuItem("Fruits");// the admin get an example photoid of teh first in line, while students get their own 
        Fruits.setFont(new Font("Segoe Script",Font.BOLD, 18));
        Quantity.add(Fruits);
        Fruits.addActionListener(e -> ShowItems("Fruits"));
        
        Vegitables = new JMenuItem("Vegitables");// the admin get an example photoid of teh first in line, while students get their own 
        Vegitables.setFont(new Font("Segoe Script",Font.BOLD, 18));
        Quantity.add(Vegitables);
        Vegitables.addActionListener(e -> ShowItems("Vegitables"));
        
        Staples = new JMenuItem("Staples");// the admin get an example photoid of teh first in line, while students get their own 
        Staples.setFont(new Font("Segoe Script",Font.BOLD, 18));
        Quantity.add(Staples);
        Staples.addActionListener(e -> ShowItems("Staples"));

        Other = new JMenuItem("Other");// the admin get an example photoid of teh first in line, while students get their own 
        Other.setFont(new Font("Segoe Script",Font.BOLD, 18));
        Quantity.add(Other);
        Other.addActionListener(e -> ShowItems("Other"));

        JMenuItem search = new JMenuItem("Search");// the admin get an example photoid of teh first in line, while students get their own 
        search.setFont(new Font("Segoe Script",Font.BOLD, 18));
        Search.add(search);
        search.addActionListener(e -> ShowItems());

        JMenuItem list = new JMenuItem("List");// the admin get an example photoid of teh first in line, while students get their own 
        list.setFont(new Font("Segoe Script",Font.BOLD, 18));
        List.add(list);
        list.addActionListener(e -> ShowItems("List"));

        JMenuItem expiration = new JMenuItem("Expiration");// the admin get an example photoid of teh first in line, while students get their own 
        expiration.setFont(new Font("Segoe Script",Font.BOLD, 18));
        Expiration.add(expiration);
        expiration.addActionListener(e -> ShowItems("Expiration"));

        menu.add(Quantity);
        menu.add(Search);
        menu.add(List);
        menu.add(Expiration);
        frame.setJMenuBar(menu);
        frame.add(intro);
        frame.setVisible(true);
    }
    public void ShowItems(String category){
        intro.setVisible(false);
        String sql = "SELECT * FROM Inventorytbl WHERE Category = '" + category + "'";
        if (category.equalsIgnoreCase("All Items") || category.equalsIgnoreCase("All"))sql = "SELECT * FROM Inventorytbl";
        if(quantity!=null)frame.remove(quantity);
        if(scrollPane != null)frame.remove(scrollPane);
        if(list!=null)frame.remove(list);
        
        JLabel info = new JLabel("Manage the availability of these items");
        info.setFont(new Font("Segoe Script",Font.BOLD, 22));
        info.setBounds(200,10, 600,40);
        frame.add(info);

        quantity = new JPanel();
        quantity.setBackground(Color.PINK);
        //quantity.setBounds(50, 50, 900, 500);
        quantity.setLayout(new GridLayout(0, 3, 20, 20));
        //quantity.setLayout(new BoxLayout(quantity, BoxLayout.Y_AXIS));
        try {
        ResultSet rs = db.find(sql);

        while (rs != null && rs.next()) {
            String name = rs.getString("ItemName");
            int qty = rs.getInt("Quantity");
            String imgPath = rs.getString("ImagePath");
            
            JPanel itemRow = new JPanel(); // A container for one food item
            //itemRow.setMaximumSize(new java.awt.Dimension(850, 100)); // Keeps rows from stretching
            itemRow.setLayout(new BoxLayout(itemRow, BoxLayout.Y_AXIS));
            itemRow.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.BLACK)); // Underline effect
            itemRow.setBackground(Color.PINK);

            ImageIcon icon = new ImageIcon(imgPath);
            Image scaledImg = icon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
            JLabel imageLabel = new JLabel(new ImageIcon(scaledImg));

            JLabel Name = new JLabel("Item: " + name);
            Name.setFont(new Font("Segoe Script",Font.BOLD, 16));
        
            JPanel controls = new JPanel();
            controls.setBackground(Color.WHITE);
            JButton minus = new JButton("-");
            
            JButton plus = new JButton("+");
            
            JLabel amount = new JLabel("Amount available: " + qty);
            amount.setFont(new Font("Segoe Script",Font.BOLD, 16));
        
            minus.addActionListener(e -> PlusMinus("minus", name, amount));
            plus.addActionListener(e -> PlusMinus("plus", name, amount));

            controls.add(minus);
            controls.add(plus);
            itemRow.add(imageLabel);
            itemRow.add(Name);
            itemRow.add(controls);
            itemRow.add(amount);            
            quantity.add(itemRow);
            
        }
        } catch (SQLException e) {
            quantity.add(new JLabel("Database Error!"));
        }
        
        scrollPane = new JScrollPane(quantity);
        scrollPane.setBounds(50, 50, 900, 550); // Set bounds on the scroll pane, NOT the quantity panel
        //frame.add(quantity);
        frame.add(scrollPane);
        
        quantity.setVisible(true);
        quantity.revalidate();
        quantity.repaint();
        frame.revalidate(); // Tells the frame it has new components
        frame.repaint();   // Tells the frame to redraw the screen
        System.out.println("Works");
    }
    public void ShowItems(){
        if(quantity!=null)frame.remove(quantity);
        if(scrollPane != null)frame.remove(scrollPane);
        if(list != null) frame.remove(list);

        list = new JPanel();//creates a new panel specifically for the grades
        list.setBounds(0,0,985,700); //sets it to around the same size as teh frame
        list.setBackground(Color.PINK);//background colour of the frame 
        list.setLayout(null);//this is so that we can control the layout, if we dont mention this, the panel will be placed anywhere, we need to set layout to null and then use set bounds

        JLabel Search = new JLabel();//same as above, a label with dimentions, coordinates and font style- form lines 84-87
        Search.setText("Search for the item you are looking for");
        Search.setBounds(200, 150, 500, 50);
        Search.setFont(new Font("Segoe Script",Font.PLAIN, 18));

        search = new JTextField();//creates a text field to get the username info 
        search.setPreferredSize(new Dimension(400,50));//sets the size of the actual textbox
        search.setBounds(200, 200, 150,50);//sets the boundaries and coordinates of where the text field is, even if the size is declared above, this helps the location
        search.setFont(new Font("Times New Roman", Font.PLAIN, 20));//font style

        JButton enter = new JButton("Enter");//a new button with the text set
        enter.setBounds(350,200, 100, 50);//sets the boundaries and coordinates of where the button is 
        enter.setFont(new Font("Segoe Script",Font.PLAIN, 21)); //sets the font style of the button 
        enter.addActionListener(e -> enter());//uses an actionlistenor to check when the button is clicked, when clicked that method is called 

        list.add(Search);
        list.add(search);
        list.add(enter);
        frame.add(list);
        list.setVisible(true);

    }
    public void enter(){
        if (searchResults != null) {
            list.remove(searchResults);
        }
        // if (list != null) {
        //     list.set;
        // }
        String SearchItem = search.getText();
        String sql = "SELECT * FROM Inventorytbl WHERE ItemName = '" + SearchItem + "'";
        String qty = db.find(sql, "Quantity");
        String exp = db.find(sql, "ExpiryDate");
        
        searchResults = new JPanel();
        searchResults.setBounds(50, 150, 850, 400); // Placed safely below the search bar
        searchResults.setBackground(Color.PINK);
        searchResults.setLayout(null); // Absolute positioning for internal text labels

        JLabel Search = new JLabel();//same as above, a label with dimentions, coordinates and font style- form lines 84-87
        Search.setText("You have searched for '"+ SearchItem+ "'");
        Search.setBounds(200, 50, 500, 50);
        Search.setFont(new Font("Segoe Script",Font.PLAIN, 18));

        JLabel item = new JLabel();//same as above, a label with dimentions, coordinates and font style- form lines 84-87
        item.setText(" -> You have "+ qty+ " items left");
        item.setBounds(200, 150, 250, 50);
        item.setFont(new Font("Segoe Script",Font.PLAIN, 18));

        JLabel expiry = new JLabel();//same as above, a label with dimentions, coordinates and font style- form lines 84-87
        expiry.setText(" -> Expiry: "+ exp);
        expiry.setBounds(200, 200, 250, 50);
        expiry.setFont(new Font("Segoe Script",Font.PLAIN, 18));

        searchResults.add(Search);
        searchResults.add(item);
        searchResults.add(expiry);

        list.add(searchResults);
        list.repaint();
        list.revalidate();
        frame.repaint();//this just makes sure no label is missing or misprint by reprinting it
        //any labels added later will also be refreshed with these lines up and below 
        frame.revalidate();
        
    }
    public void PlusMinus(String choice, String Itemname, JLabel labelToUpdate){
        String text  = labelToUpdate.getText();
        int currentQty = Integer.parseInt(text.substring(text.lastIndexOf(" ") + 1));
        
        int newQty = currentQty;
        if (choice.equals("plus")) {
            newQty++;
        } else if (choice.equals("minus") && currentQty > 0) {
            newQty--;
        }
        db.update(Itemname, newQty);
        labelToUpdate.setText("Amount available: " + newQty);

        if (choice.equals("minus")) {
            String sql = "SELECT QuantityType FROM Inventorytbl WHERE ItemName = '" + Itemname + "'"; 
            String unitType = db.find(sql, "QuantityType");
            if (unitType.equalsIgnoreCase("Pack") && newQty == 0) {
                showStock(Itemname);
            } 
            else if (unitType.equalsIgnoreCase("Individual") && newQty < 3) {
                showStock(Itemname);
            }
        }
    }
    public void showStock(String itemName){
        Object[] options = {"Shop", "Dismiss"};
        int choice = JOptionPane.showOptionDialog(
        frame, 
        "You are running low on " + itemName + "!", 
        "Low Stock Warning", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, 
        null, options, options[0]); 

        if (choice == JOptionPane.YES_OPTION) {
            System.out.println("Redirecting to shopping link");
            try {            
                String sql = "SELECT ShopLink FROM Inventorytbl WHERE ItemName = '" + itemName + "'";
                String link = db.find(sql, "ShopLink");

                if (link != null && !link.isEmpty() && Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().browse(new URI(link));
                } else {
                    System.out.println("Could not open browser. Link is empty or desktop browsing is not supported.");
                }
            } catch (Exception e) {
                System.err.println("Error trying to open link: " + e.getMessage());
            }
        }
    }


}
