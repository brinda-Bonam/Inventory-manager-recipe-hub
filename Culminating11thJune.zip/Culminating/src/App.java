//Sreebrinda Bonam
//June 7th to June 16th 
//Culminating- Pantry organizer
// A system to organize and store data about your pantry using database and can lead ypu to chrome or an outside website when you press shop!



//Enhancement- GUI- Jframe using java swing


//This is teh same video i used for assignment 1 and 4 for JFrame graphics
// https://youtu.be/Kmgo00avvEw?si=ysqPq5iRRgMV81id
//polymorphism info, again same as assignment 4
//https://www.w3schools.com/JAVA/java_polymorphism.asp

//There are more refreneces in the other classes as well!!!
import java.io.File;
import java.util.Scanner;//Just like in the first assignment i was worried id lose marks for naming teh file wrong, so i made sure to get inputs in console if i cant find teh file

public class App {
    static Scanner scan = new Scanner(System.in);
    static String file = "src\\Inventory.accdb";//hopefully the naming doesnt go wrong but the file path to the database   
    
    public static void main(String[] args) throws Exception {
       
        checkfile();
        Database db = new Database();
        db.setter(file);

        Jframe Frame = new Jframe();
        Frame.MyFrame();
        System.out.println("Hello, World!");
    }
    public static void checkfile(){
        File dbFile = new File(file);//creates a file to check since the file path from before is simply a string
        if (!dbFile.exists()) {//uses recusrion so need if statements or a way out
            System.out.println("Error: Database file not found at " + dbFile.getAbsolutePath());//prints that teh prvios path given is wrong
            System.out.println("Enter the exact relative path to the accdb file!!!\nIt should be in the src folder so please dont move it around!!");//explains and asks to get teh exact file path 
            file = scan.nextLine();//stores the file value
            checkfile();//uses recursion to makee sure that the file is actually found/exists
        }
        else{
            System.out.println("file found!!");//if the file exists and is found, then recursion ends 
            return;
        }


    }
}
